/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stack;

/**
 *
 * @author ESHOP
 */
public class Stack {
    
    public class Node{
    int data;
    Node next;
    Node(int data){
        this.data=data;
        this.next=null;
    }
}
    private Node top;
    Stack(){
        this.top=null;
    }
    public void push(int data){
        Node newNode=new Node(data);
        if(top==null){
            top=newNode;
            return;
        }
        newNode.next=top;
        top= newNode;
    }
    public int peek(){
        return top.data;
    }
    public int pop(){
       
        int temp=top.data;
        top=top.next;
        
        return temp;
    }
    public boolean isempty(){
        return top==null;
        
    }
    public void display(){
        if(top==null){
            System.out.println("Stack is empty");
            
        }   else{
            Node current=top;
            while(current!=null){
                System.out.println(current.data);
                current=current.next;
                
            }
            
        }
    }
    public static void main(String[] args) {
        Stack st=new Stack();
       st.push(20);
        st.push(50);
        st.display();
        st.peek();
        st.pop();
        st.peek();
        st.display();
        st.isempty();
    }      
    
}
