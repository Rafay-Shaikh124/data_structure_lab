/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stack2;

/**
 *
 * @author ESHOP
 */
public class Stack2 {
    int[] arr=new int[5];
   int top=-1;
   public void push(int data){
       if(top>=arr.length-2){
           System.out.println("stack is over flow");
       }
       else{
           top++;
           arr[top]=data;
       }
       
   }
   public void pop(){
    if(top<0) {
        System.out.println("stack is under the flow");
    }  
    else{
        top--;
        
    }
   }
   public void peak(){
       
       for(int i=0; i<=top; i++){
           System.out.println(arr[top]);
           break;
       }
       
       
             
   }
   public boolean isempty(){
      return top==-1;
   }
   
   
    public static void main(String[] args) {
        // TODO code application logic here
        Stack2 a=new Stack2();
        a.push(3);
        a.push(5);
        a.push(7);
        a.push(8);
        a.peak();
       
       
        //a.pop();
       //a.peak();
        System.out.println(a.isempty());
        
    }

  
}
