/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication15;

/**
 *
 * @author Ali Computers
 */
public class JavaApplication15 {

   public class Node{
       
       int data;
       Node next;
       Node prev;
       
       Node( int data){
           this.data=data;
           this.next=null;
           this.prev=null;          
        }  
   }
   
   private Node head;
   private Node tail;
   
   public JavaApplication15(){
       this.head=null;
       this.tail=null;
       
   }
   
   public void addAtStart(int data){
       Node newnode=new Node(data);
       if (head==null){
           head=tail=newnode;
       }
       else{
           newnode.next=head;
           head.prev=newnode;
           head=newnode;
       }
   }
   
   public void addAtEnd(int data){
       Node newnode=new Node(data);
       if(head==null){
           head=tail=newnode;
           
       }
       else{
           Node current=head;
           while(current.next!=null){
               current=current.next;
          
           }
           current.next=newnode;
                newnode.prev=current;
       }
   }
   
  
   
   public void displayfromstart(){
       Node current=head;
       while(current !=null){
           System.out.println(current.data+"->");
           current=current.next;
           
       }
       
       System.out.println("null");
   }
   
   public void addAtmiddle(int data,int pos){
 
       Node newnode=new Node(data);
       
Node current=head;
for(int i=0;i<pos-1;i++){
    current=current.next;
    }
newnode.next=current.next;
newnode.prev=current.prev;
current.next=newnode;
   }
   
   public void deletefromstart(int data){
       if (head == null) {  
        System.out.println("The list is empty, nothing to delete.");
        return;
    }
    
       head = head.next;  
       head.prev = null;  
    
   }
   
    public void deletefromend(int data){
       if (tail == null) {  
        System.out.println("The list is empty, nothing to delete.");
        return;
    }
    
       tail = tail.prev;  
       tail.next = null;  
    
   }
   
   public void deletebyvalue(int value){
       Node current=head;
       if (current.data==value){
           current.prev.next=current.next;
           current.next.prev=current.prev;
           
       }
       if(current.next==null){
       current.prev.next=null;
       }
   }
    
    public static void main(String[] args) {
       JavaApplication15 list=new JavaApplication15();
        list.addAtStart(3);
        list.addAtmiddle(4, 1);
        list.addAtEnd(10);
        list.displayfromstart();
        list.deletebyvalue(5);
        list.displayfromstart();
        
    }
    
}

